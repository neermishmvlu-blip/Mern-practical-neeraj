import { useEffect, useState } from "react";
import axios from "axios";
import "./App.css";

const API = "http://localhost:5000/api/books";

const CATEGORIES = [
  "Programming",
  "Database",
  "Networking",
  "Artificial Intelligence",
  "Web Development",
  "Other"
];

const emptyForm = {
  title: "",
  author: "",
  isbn: "",
  category: "",
  copies: "",
  price: ""
};

function App() {
  const [books, setBooks] = useState([]);
  const [search, setSearch] = useState("");
  const [form, setForm] = useState(emptyForm);
  const [editId, setEditId] = useState(null);
  const [errors, setErrors] = useState({});
  const [message, setMessage] = useState({ type: "", text: "" });

  // Get books (also used for search)
  const getBooks = () => {
    axios
      .get(API, { params: { search: search } })
      .then((response) => {
        setBooks(response.data);
      })
      .catch((error) => {
        console.log(error);
        showMessage("error", "Unable to load books. Is the server running?");
      });
  };

  useEffect(() => {
    getBooks();
  }, [search]);

  const showMessage = (type, text) => {
    setMessage({ type: type, text: text });
    setTimeout(() => setMessage({ type: "", text: "" }), 4000);
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  // Frontend validation
  const validate = () => {
    const err = {};

    if (!form.title.trim()) err.title = "Title is required";
    else if (form.title.trim().length < 2)
      err.title = "Title must be at least 2 characters";
    else if (!/^[A-Za-z0-9 .,:'&()-]+$/.test(form.title.trim()))
      err.title = "Title contains invalid characters";

    if (!form.author.trim()) err.author = "Author is required";
    else if (!/^[A-Za-z .'-]{2,50}$/.test(form.author.trim()))
      err.author = "Author must contain only letters (2-50)";

    if (!form.isbn.trim()) err.isbn = "ISBN is required";
    else if (!/^(\d{10}|\d{13})$/.test(form.isbn.trim()))
      err.isbn = "ISBN must be 10 or 13 digits";

    if (!form.category) err.category = "Please select a category";

    if (form.copies === "") err.copies = "Copies is required";
    else if (!Number.isInteger(Number(form.copies)))
      err.copies = "Copies must be a whole number";
    else if (Number(form.copies) < 1 || Number(form.copies) > 100)
      err.copies = "Copies must be between 1 and 100";

    if (form.price === "") err.price = "Price is required";
    else if (isNaN(Number(form.price)))
      err.price = "Price must be a valid number";
    else if (Number(form.price) < 1 || Number(form.price) > 10000)
      err.price = "Price must be between 1 and 10000";

    setErrors(err);
    return Object.keys(err).length === 0;
  };

  // Add or Update book
  const handleSubmit = (e) => {
    e.preventDefault();

    if (!validate()) {
      showMessage("error", "Please correct the errors in the form");
      return;
    }

    const bookData = {
      title: form.title.trim(),
      author: form.author.trim(),
      isbn: form.isbn.trim(),
      category: form.category,
      copies: Number(form.copies),
      price: Number(form.price)
    };

    const request = editId
      ? axios.put(`${API}/${editId}`, bookData)
      : axios.post(API, bookData);

    request
      .then((response) => {
        showMessage("success", response.data.message);
        resetForm();
        getBooks();
      })
      .catch((error) => {
        console.log(error);
        const data = error.response?.data;
        if (data?.errors) showMessage("error", data.errors.join(", "));
        else showMessage("error", data?.message || "Something went wrong");
      });
  };

  // Edit book
  const handleEdit = (book) => {
    setEditId(book._id);
    setForm({
      title: book.title,
      author: book.author,
      isbn: book.isbn,
      category: book.category,
      copies: book.copies,
      price: book.price
    });
    setErrors({});
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Delete book (with confirmation)
  const handleDelete = (book) => {
    if (!window.confirm(`Are you sure you want to delete "${book.title}"?`)) {
      return;
    }

    axios
      .delete(`${API}/${book._id}`)
      .then((response) => {
        showMessage("success", response.data.message);
        getBooks();
      })
      .catch((error) => {
        console.log(error);
        showMessage("error", error.response?.data?.message || "Error deleting book");
      });
  };

  const resetForm = () => {
    setForm(emptyForm);
    setEditId(null);
    setErrors({});
  };

  return (
    <div className="container">
      <h1>Library Book Management System</h1>

      {message.text && (
        <div className={`message ${message.type}`}>{message.text}</div>
      )}

      {/* Add / Update Form */}
      <h2>{editId ? "Update Book" : "Add New Book"}</h2>

      <form onSubmit={handleSubmit} noValidate>
        <input
          type="text"
          name="title"
          placeholder="Book Title"
          value={form.title}
          onChange={handleChange}
        />
        {errors.title && <p className="error">{errors.title}</p>}

        <input
          type="text"
          name="author"
          placeholder="Author"
          value={form.author}
          onChange={handleChange}
        />
        {errors.author && <p className="error">{errors.author}</p>}

        <input
          type="text"
          name="isbn"
          placeholder="ISBN (10 or 13 digits)"
          value={form.isbn}
          onChange={handleChange}
        />
        {errors.isbn && <p className="error">{errors.isbn}</p>}

        <select name="category" value={form.category} onChange={handleChange}>
          <option value="">Select Category</option>
          {CATEGORIES.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
        {errors.category && <p className="error">{errors.category}</p>}

        <input
          type="number"
          name="copies"
          placeholder="Number of Copies"
          value={form.copies}
          onChange={handleChange}
        />
        {errors.copies && <p className="error">{errors.copies}</p>}

        <input
          type="number"
          name="price"
          placeholder="Price"
          value={form.price}
          onChange={handleChange}
        />
        {errors.price && <p className="error">{errors.price}</p>}

        <div className="buttons">
          <button type="submit" className="primary">
            {editId ? "Update Book" : "Add Book"}
          </button>
          {editId && (
            <button type="button" onClick={resetForm}>
              Cancel
            </button>
          )}
        </div>
      </form>

      <hr />

      {/* Search */}
      <h2>Book List</h2>

      <input
        type="text"
        placeholder="Search by title, author, ISBN or category"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      <table border="1">
        <thead>
          <tr>
            <th>Title</th>
            <th>Author</th>
            <th>ISBN</th>
            <th>Category</th>
            <th>Copies</th>
            <th>Price</th>
            <th>Actions</th>
          </tr>
        </thead>

        <tbody>
          {books.length === 0 ? (
            <tr>
              <td colSpan="7">No books found</td>
            </tr>
          ) : (
            books.map((book) => (
              <tr key={book._id}>
                <td>{book.title}</td>
                <td>{book.author}</td>
                <td>{book.isbn}</td>
                <td>{book.category}</td>
                <td>{book.copies}</td>
                <td>{book.price}</td>
                <td>
                  <button onClick={() => handleEdit(book)}>Edit</button>{" "}
                  <button className="danger" onClick={() => handleDelete(book)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

export default App;
