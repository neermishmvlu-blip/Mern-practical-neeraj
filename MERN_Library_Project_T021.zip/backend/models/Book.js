const mongoose = require("mongoose");

const CATEGORIES = [
  "Programming",
  "Database",
  "Networking",
  "Artificial Intelligence",
  "Web Development",
  "Other"
];

const bookSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, "Title is required"],
      trim: true,
      minlength: [2, "Title must be at least 2 characters"],
      maxlength: [100, "Title must not exceed 100 characters"],
      match: [/^[A-Za-z0-9 .,:'&()-]+$/, "Title contains invalid characters"]
    },
    author: {
      type: String,
      required: [true, "Author is required"],
      trim: true,
      minlength: [2, "Author must be at least 2 characters"],
      maxlength: [50, "Author must not exceed 50 characters"],
      match: [/^[A-Za-z .'-]+$/, "Author must contain only letters"]
    },
    isbn: {
      type: String,
      required: [true, "ISBN is required"],
      unique: true,
      trim: true,
      match: [/^(\d{10}|\d{13})$/, "ISBN must be 10 or 13 digits"]
    },
    category: {
      type: String,
      required: [true, "Category is required"],
      enum: { values: CATEGORIES, message: "Invalid category" }
    },
    copies: {
      type: Number,
      required: [true, "Number of copies is required"],
      min: [1, "Copies must be at least 1"],
      max: [100, "Copies must not exceed 100"],
      validate: {
        validator: Number.isInteger,
        message: "Copies must be a whole number"
      }
    },
    price: {
      type: Number,
      required: [true, "Price is required"],
      min: [1, "Price must be at least 1"],
      max: [10000, "Price must not exceed 10000"]
    }
  },
  { timestamps: true }
);

module.exports = mongoose.model("Book", bookSchema);
