require("dotenv").config();

const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const Book = require("./models/Book");

const app = express();
const PORT = process.env.PORT || 5000;
const MONGO_URI =
  process.env.MONGO_URI || "mongodb://127.0.0.1:27017/LibraryDB";

// Middleware
app.use(cors());
app.use(express.json());

// Connect MongoDB
mongoose
  .connect(MONGO_URI)
  .then(() => console.log("MongoDB Connected Successfully"))
  .catch((error) => {
    console.log("MongoDB Connection Failed");
    console.log(error.message);
  });

// Common error handler for all routes
const handleError = (error, res) => {
  if (error.name === "ValidationError") {
    const errors = Object.values(error.errors).map((e) => e.message);
    return res.status(400).json({ message: "Validation failed", errors });
  }
  if (error.name === "CastError") {
    return res.status(400).json({ message: "Invalid book ID" });
  }
  if (error.code === 11000) {
    return res
      .status(409)
      .json({ message: "A book with this ISBN already exists" });
  }
  console.log(error);
  res.status(500).json({ message: "Server error. Please try again." });
};

// Home API
app.get("/", (req, res) => {
  res.send("Library Book Management API is Running");
});

// GET /api/books?search=text
// View all books (with optional search)
app.get("/api/books", async (req, res) => {
  try {
    const search = (req.query.search || "").trim();
    let filter = {};

    if (search) {
      const safe = search.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      const regex = new RegExp(safe, "i");
      filter = {
        $or: [
          { title: regex },
          { author: regex },
          { isbn: regex },
          { category: regex }
        ]
      };
    }

    const books = await Book.find(filter).sort({ createdAt: -1 });
    res.json(books);
  } catch (error) {
    handleError(error, res);
  }
});

// POST /api/books
// Add a new book
app.post("/api/books", async (req, res) => {
  try {
    const existing = await Book.findOne({ isbn: req.body.isbn });
    if (existing) {
      return res
        .status(409)
        .json({ message: "A book with this ISBN already exists" });
    }

    const book = await Book.create(req.body);
    res.status(201).json({ message: "Book added successfully", book });
  } catch (error) {
    handleError(error, res);
  }
});

// PUT /api/books/:id
// Update an existing book
app.put("/api/books/:id", async (req, res) => {
  try {
    const duplicate = await Book.findOne({
      isbn: req.body.isbn,
      _id: { $ne: req.params.id }
    });
    if (duplicate) {
      return res
        .status(409)
        .json({ message: "A book with this ISBN already exists" });
    }

    const book = await Book.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });

    if (!book) {
      return res.status(404).json({ message: "Book not found" });
    }

    res.json({ message: "Book updated successfully", book });
  } catch (error) {
    handleError(error, res);
  }
});

// DELETE /api/books/:id
// Delete a book
app.delete("/api/books/:id", async (req, res) => {
  try {
    const book = await Book.findByIdAndDelete(req.params.id);

    if (!book) {
      return res.status(404).json({ message: "Book not found" });
    }

    res.json({ message: "Book deleted successfully" });
  } catch (error) {
    handleError(error, res);
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
