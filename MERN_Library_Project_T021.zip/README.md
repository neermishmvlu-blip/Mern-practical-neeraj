# Library Book Management System (MERN Stack)

**Student:** Neeraj Mishra | **Roll No:** T021 | **Class:** TYIT (B.Sc. IT, Semester V)

## Description
A full-stack web application to manage the books of a college library. Users can add, view, update, delete and search books. Data is validated on both the frontend (React) and the backend (Express + Mongoose) and stored in MongoDB.

## Features
- Add, view, update and delete books (CRUD)
- Search by title, author, ISBN or category
- Frontend and backend validation (required fields, text format, numeric ranges)
- Duplicate ISBN handling
- Confirmation before deleting
- Success and error messages

## Technologies Used
React (Vite), Node.js, Express.js, MongoDB, Mongoose, Axios, Visual Studio Code, Git and GitHub

## How to Run

### 1. Backend
```
cd backend
npm install
copy .env.example .env      (Windows)   |   cp .env.example .env   (Mac/Linux)
npm start
```
The API runs on http://localhost:5000 (MongoDB must be running on port 27017).

### 2. Frontend
```
npm create vite@latest frontend -- --template react   (only the first time; keep the existing src files)
cd frontend
npm install axios
```
Copy `src/App.jsx` and `src/App.css` into the frontend `src` folder, then:
```
npm run dev
```
Open http://localhost:5173

## API Endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | /api/books?search=text | View / search books |
| POST | /api/books | Add a book |
| PUT | /api/books/:id | Update a book |
| DELETE | /api/books/:id | Delete a book |

## Validation Rules
- Title: required, 2-100 characters
- Author: required, letters only, 2-50 characters
- ISBN: required, 10 or 13 digits, must be unique
- Category: required, from the list
- Copies: whole number, 1-100
- Price: number, 1-10000
